Holly Loomer
661109104



For this lab, it took me a while to figure out how the appending/moving/3 second interval was going to work.

Once this part was finished, I realized that I could have done it an easier way.

At first, I was just going to put all of the items into variables and these variables would contain the html for the divs. But then, I decided on making separate arrays. In the end, I just ended up putting whatever was in these arrays, into variables holding HTML tags. 

If I could do this lab again, I would probably not have done this extra step of storing in arrays. It confused and complicated what I was trying to do just a bit more.

I also heard from a friend in another class it would be better to load all the data into the HTML, and then modify on it. If the javascript fails on someone's browser, and there are a lot of dependencies, then my tickers would not work. I never figured out how to be able to do this so that it is not as javascript dependent. I would LOVE to learn how to do that though.

My design for the twitter feed and hashtag feed stemmed solely from the website itself. Bubbly items, fun, and shades of blue/white/grey/black were what reminded me of twitter and it's logo.

Also, I used w3schools for a lot of resources. Stack overflow helped me understand certain jquery functions as well so I could utilize them properly.

The tweets-clean.json file also was slightly modified, in that I named the array of json objects (each tweet) as "tweet" so I could access the items through ajax easier.