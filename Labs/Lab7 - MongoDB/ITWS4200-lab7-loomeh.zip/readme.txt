Holly Loomer
661109104 - loomeh


I used the command prompt to start up the database connection, the nodejs connection, and the mongoshell to debug small things.
For the database connection, I called the database twitter and lead to that path in my command prompt  to start the connection. (c:/mongo/bin --dbpath C:/mongo/data/twitter).
I created my database under the path of c:/mongo/data/twitter.
For the node.js server, I run node buildserver.js.


From the previous lab 6, I broke the conversion to CSV. I knew my solution for the lab was temporary and it was not fully correct to begin with, so I did not spend my time focusing on fixing that button. 
Lab 6 I got as close to it as I could. I am still curious as to how it was done specifically.

I am streaming in 20 tweets at a time.

I talked to Professor Plotka about my css / styling because it was not being brought in correctly to my index.html. The response of the css file sending through the server was not being sent correctly, even though my javascript was being sent correctly. After looking at it for a while he said just to embed it in my html and say in my readme that he said it was okay, which is what I currently have.