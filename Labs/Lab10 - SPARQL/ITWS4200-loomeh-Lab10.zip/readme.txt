For question 4, I was unsure of what order the items should go in, because I think it might have affected the result. So I ordered it in the order that the question had asked us to complete the task.

For the FOAF file, I completed the lab before candice and madi and so I was unsure of what email they were going to use. So I was not able to link to their RDFs (plus they did not put it up on personal websites like the examples had shown, so I wouldn't have been able to link to it).
Also, I did not input things I could not find for myself.
I used the FOAF-o-matic to help me with syntax and learn how the file is structured more.